const num = document.querySelector(".number");
var i = 1;
        function plus(){
            num.textContent++;
            i++;
        }
        function minus(){
            if(num.textContent != 1)
            {
                i--;
                num.textContent = i;
            }
        }
        function delAll(){

        }
        function finish(){

        }
        function del(){

        }