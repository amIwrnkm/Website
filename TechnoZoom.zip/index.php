<script>
    location.replace("php/index.php");
</script>