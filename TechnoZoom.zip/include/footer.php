<footer class="row">
            <div class="col-6 col-md-4">
                <ul>
                    <li><p class="bold">راه های ارتباط</p></li>
                    <li>:شماره تماس</li>
                    <li><a href="tel.0921">0921 *** **09</a></li>
                    <li>ایمیل:</li>
                    <li><a href="mailto: email@gmail.com">email@gmail.com</a></li>
                </ul>
            </div>
            <div class="d-none d-md-block col-md-4">
                <ul>
                    <li><p class="bold">بخش های سایت</p></li>
                    <li><a href="../index.php">صفحه‌اصلی</a></li>
                    <li><a href="../php/Products.php">محصولات</a></li>
                    <li><a href="../php/logn.php">ورود</a></li>
                </ul>
            </div>
            <div class="col-6 col-md-4">
                <ul>
                    <li><p class="bold">درباره تکنوزوم</p></li>
                    <li>تکنوزوم در تلاش هست که بتواند<br>
                        قطعات سخت افزاری را بدون دخالت واسطه<br>
                        به دست مشتری برساند</li>
                    <li><a href="../php/about.php">ادامه درباره‌ما</a></li>
                </ul>
            </div>
            <div class="col-8">
                <ul class="row link">
                    <li class="col-3  d-none d-sm-block"><a href="#">Linkedin</a></li>
                    <li class="col-3  d-none d-sm-block"><a href="#">Instagram</a></li>
                    <li class="col-3  d-none d-sm-block"><a href="#">Telegram</a></li>
                    <li class="col-3  d-none d-sm-block"><a href="#">Facebook</a></li>
                </ul>
            </div>
        </footer>
    </div>
    <script src="../js/aside.js"></script>
    <script src="../js/search.js"></script>
</body>
</html>