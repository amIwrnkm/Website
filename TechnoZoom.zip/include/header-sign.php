<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ثبت نام</title>
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/Logn-Sing.css">
    <link rel="stylesheet" href="../css/color-library.css">
</head>
<body>
<section class="container col-10 col-sm-8 col-md-5">
            <div class="row header">
                <h1 class="col-12">Technozoom</h1>
            </div>
            <div class="line"></div>