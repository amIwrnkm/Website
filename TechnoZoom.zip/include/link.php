<!--$link =mysqli_connect("localhost", "root" ,"", "shop-db");-->
$link =mysqli_connect("localhost", "root" ,"", "shop-db");