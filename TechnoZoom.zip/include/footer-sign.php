
<samp class="d-none d-sm-block col-2">&nbsp;</samp>
                <a class="col-6 col-sm-3" href="../index.php">Home</a>
            </div>
    </section>

    <script src="../js/bootstrap.js"></script>
</body>
</html>